package com.ride.service;

import com.ride.entity.VehicleDetails;

public interface IVehicleService {
    public void saveVehicle(VehicleDetails vehicleDetails);
}
